﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace newForm1
{
    public partial class Admin : Form
    {
        public Admin()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            label1.Text = "Welcome, " +Connection.UserName;
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void bookToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void Admin_Load(object sender, EventArgs e)
        {

        }

        private void detailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BookDetails bookDetails = new BookDetails();
            bookDetails.Show();
            this.Hide();
        }

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddBook addBook = new AddBook();
            addBook.Show();
            this.Hide();
        }

        private void managerToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Hide();
        }

        private void emailAlertToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void bookToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            DeuBookList deuBookList = new DeuBookList();
            deuBookList.Show();
            this.Hide();
        }

        private void visionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Vision vision = new Vision();
            vision.Show();
            this.Hide();
        }

        private void registerListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RegisterList registerList = new RegisterList();
            registerList.Show();
            this.Hide();
        }
    }
}
