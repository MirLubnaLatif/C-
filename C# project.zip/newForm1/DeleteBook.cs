﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace newForm1
{
    public partial class DeleteBook : Form
    {
        SqlConnection connection = new SqlConnection("Data Source = Localhost; Initial Catalog = Library1; Integrated Security = True");
        public DeleteBook()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int i;
            i = Convert.ToInt32(dataGridView1.SelectedCells[0].Value.ToString());
            try
            {
                connection.Open();
                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.Text;
                command.CommandText = "select * from BookDetail where BookID = " + i + "";
                command.ExecuteNonQuery();
                DataTable dataTable = new DataTable();
                SqlDataAdapter dataAdapter = new SqlDataAdapter(command);

                dataAdapter.Fill(dataTable);


                foreach (DataRow dataRow in dataTable.Rows)
                {
                    textBox1.Text = dataRow["BookName"].ToString();
                    
                }
                connection.Close();



            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);
            }
        }

        private void DeleteBook_Load(object sender, EventArgs e)
        {
            disp_Books();
        }
        public void disp_Books()
        {
            try
            {
                connection.Open();
                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.Text;
                command.CommandText = "select * from BookDetail";
                command.ExecuteNonQuery();
                DataTable dataTable = new DataTable();
                SqlDataAdapter dataAdapter = new SqlDataAdapter(command);

                dataAdapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;
                ///MessageBox.Show("Book is Added to the Book List");
                connection.Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);
            }
        }

        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            int count = 0;
            try
            {
                connection.Open();
                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.Text;
                command.CommandText = "select * from BookDetail where BookName like ('%" + textBox1.Text + "%')";
                command.ExecuteNonQuery();
                DataTable dataTable = new DataTable();
                SqlDataAdapter dataAdapter = new SqlDataAdapter(command);

                dataAdapter.Fill(dataTable);

                count = Convert.ToInt32(dataTable.Rows.Count.ToString());
                dataGridView1.DataSource = dataTable;

                if (count == 0)
                {
                    MessageBox.Show("Book Name is no found in the Book List");
                }
                ///MessageBox.Show("Book is Added to the Book List");
                connection.Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int count = 0;
            try
            {
                connection.Open();
                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.Text;
                command.CommandText = "delete from BookDetail where BookName like ('%" + textBox1.Text + "%')";
                command.ExecuteNonQuery();
                DataTable dataTable = new DataTable();
                SqlDataAdapter dataAdapter = new SqlDataAdapter(command);

                dataAdapter.Fill(dataTable);

                count = Convert.ToInt32(dataTable.Rows.Count.ToString());
                dataGridView1.DataSource = dataTable;

                if (count == 0)
                {
                    MessageBox.Show("Book Name is Deleted from the Book List");
                }
                ///MessageBox.Show("Book is Added to the Book List");
                connection.Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            BookDetails bookDetails = new BookDetails();
            bookDetails.Show();
            this.Hide();
        }
    }
}
