﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace newForm1
{
    public partial class IssueBokk : Form
    {
        SqlConnection connection = new SqlConnection("Data Source = Localhost; Initial Catalog = Library1; Integrated Security = True");
        public IssueBokk()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int i = 0;
            SqlCommand command = connection.CreateCommand();
            command.CommandType = CommandType.Text;
            command.CommandText = "select * from StudentInfo where StudentClsID like ('%" + StudentClsID.Text + "%')";
            command.ExecuteNonQuery();
            DataTable dataTable = new DataTable();
            SqlDataAdapter dataAdapter = new SqlDataAdapter(command);

            dataAdapter.Fill(dataTable);
            i = Convert.ToInt32(dataTable.Rows.Count.ToString());
            if (i == 0)
            {
                MessageBox.Show("Student Id not found");
            }
            
                foreach (DataRow dataRow in dataTable.Rows)
                {
                    StudentName.Text = dataRow["StudentName"].ToString();
                    StudentDepartment.Text = dataRow["StudentDepartment"].ToString();
                    StudentSem.Text = dataRow["StudentSem"].ToString();
                    StudentContact.Text = dataRow["StudentContact"].ToString();
                    StudentEmail.Text = dataRow["StudentEmail"].ToString();
                   // BookIssueDate.Text = dataRow["BookIssueDate"].ToString();
                   // BookName.Text = dataRow["BookName"].ToString();
                }
            
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void IssueBokk_Load(object sender, EventArgs e)
        {
            if (connection.State == ConnectionState.Open)
            {
                connection.Close();
            }
            connection.Open();
        }

        private void BookName_KeyUp(object sender, KeyEventArgs e)
        {
            int count =0 ;
            if (e.KeyCode != Keys.Enter)
            {
                listBox1.Items.Clear();
                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.Text;
                command.CommandText = "select * from BookDetail where BookName like ('%" + BookName.Text + "%')";
                command.ExecuteNonQuery();
                DataTable dataTable = new DataTable();
                SqlDataAdapter dataAdapter = new SqlDataAdapter(command);

                dataAdapter.Fill(dataTable);
                count = Convert.ToInt32(dataTable.Rows.Count.ToString());

                if(count >0)
                {
                    listBox1.Visible = true;

                    foreach(DataRow dataRow in dataTable.Rows)
                    {
                        listBox1.Items.Add(dataRow["BookName"].ToString());
                    }
                }
            }
        }

        private void BookName_KeyDown(object sender, KeyEventArgs e)
        {
            int count = 0;
            if (e.KeyCode != Keys.Enter)
            {
                listBox1.Items.Clear();
                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.Text;
                command.CommandText = "select * from BookDetail where BookName like ('%\" + BookName.Text + \"%')";
                command.ExecuteNonQuery();
                DataTable dataTable = new DataTable();
                SqlDataAdapter dataAdapter = new SqlDataAdapter(command);

                dataAdapter.Fill(dataTable);
                count = Convert.ToInt32(dataTable.Rows.Count.ToString());

                if (count > 0)
                {
                    listBox1.Visible = true;

                    foreach (DataRow dataRow in dataTable.Rows)
                    {
                        listBox1.Items.Add(dataRow["BookName"].ToString());
                    }
                }
            }

        }

        private void listBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Enter)
            {
                
                BookName.Text = listBox1.SelectedItem.ToString();
                listBox1.Visible= false;
            }
        }

        private void BookName_MouseClick(object sender, MouseEventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int bookQuantity =0;
            
                listBox1.Items.Clear();
                SqlCommand command2 = connection.CreateCommand();
                command2.CommandType = CommandType.Text;
                command2.CommandText = "select * from BookDetail where BookName ='" + BookName.Text + "'";
                command2.ExecuteNonQuery();
                DataTable dataTable2 = new DataTable();
                SqlDataAdapter dataAdapter2 = new SqlDataAdapter(command2);

                dataAdapter2.Fill(dataTable2);
               // count = Convert.ToInt32(dataTable.Rows.Count.ToString());

               
                    foreach (DataRow dataRow2 in dataTable2.Rows)
                    {
                        bookQuantity = Convert.ToInt32(dataRow2["AvailableBook"].ToString());
                    }

            if (bookQuantity > 0)
            {
                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.Text;
                command.CommandText = "insert into IssueBokk values" +
                    " ('" + StudentClsID.Text + "','" + StudentName.Text + "','" + StudentDepartment.Text + "','" + StudentSem.Text + "','" + StudentEmail.Text + "','" + StudentContact.Text + "','" + BookName.Text + "','" + dateTimePicker1.Value.ToShortDateString() + "','')";
                command.ExecuteNonQuery();

                SqlCommand command1 = connection.CreateCommand();
                command1.CommandType = CommandType.Text;
                command1.CommandText = "update BookDetail set AvailableBook =AvailableBook-1 where BookName ='" + BookName.Text + "'";
                command1.ExecuteNonQuery();

                MessageBox.Show("Book Issued");
            }

            else
            {
                MessageBox.Show("Book is not Available");
            }
 
        }

        private void listBox1_MouseClick(object sender, MouseEventArgs e)
        {
            

                BookName.Text = listBox1.SelectedItem.ToString();
                listBox1.Visible = false;
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ManagerForm managerForm = new ManagerForm();
            managerForm.Show();
            this.Hide();
        }
    }
}
