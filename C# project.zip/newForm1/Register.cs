﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace newForm1
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!IsValid())
                return;
            
            try
            {
                SqlConnection connection = new SqlConnection("Data Source=Localhost;Initial Catalog=Library1;Integrated Security=True");
                connection.Open();
                string query = "Insert into UserInfo(Name,Email,PhoneNumber,UserName,Password,UserType,Status) " +
                    "values('"+textBox1.Text+"','"+textBox2.Text+"','"+textBox3.Text+"','"+textBox4.Text+"','"+textBox6.Text+"','"+(int)EnumCls.UserType.Users+"','"+(int)EnumCls.Status.PendingRequest+"')";

               // MessageBox.Show(query);

                SqlCommand command = new SqlCommand(query,connection);

                int row = command.ExecuteNonQuery();

                if( row > 0)
                {
                    MessageBox.Show("Registration Completed");
                }

                else
                {
                    MessageBox.Show("Registration Completed");
                }
                
                
            }
            catch(Exception exception)
            {
                MessageBox.Show(exception.Message);
               
            }
        }

        private bool IsValid()
        {
            if(string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrWhiteSpace(textBox1.Text))
            {
                MessageBox.Show("Please Enetr Your Name");
                textBox1.Focus();
                return false;
            }

            string email = textBox2.Text;
            if(!email.Contains(".") || !email.Contains("@"))
            {
                MessageBox.Show("Invalid Email");
                textBox2.Focus();
                return false;
            }

            if (string.IsNullOrEmpty(textBox4.Text) || string.IsNullOrWhiteSpace(textBox4.Text))
            {
                MessageBox.Show("Please Enetr Your Name");
                textBox4.Focus();
                return false;
            }

            if (textBox5.Text != textBox6.Text)
            {
                MessageBox.Show("Password and Confirm Password should be matched");
                textBox6.Focus();
                return false;
            }

            return true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Hide();
        }
    }
}
