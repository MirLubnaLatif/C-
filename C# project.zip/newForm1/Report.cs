﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.ReportSource;
using CrystalDecisions.Windows.Forms;

namespace newForm1
{
    public partial class Report : Form
    {
        SqlConnection connection = new SqlConnection("Data Source = Localhost; Initial Catalog = Library1; Integrated Security = True");
        public Report()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //DataSet dataSet = new DataSet();
            try
            {
                DataSet2 dataSet = new DataSet2();
                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.Text;
                command.CommandText = "select * from IssueBokk Where BookReturnDate=''";
                command.ExecuteNonQuery();
                DataTable dataTable = new DataTable();
                SqlDataAdapter dataAdapter = new SqlDataAdapter(command);
                
                dataAdapter.Fill(dataSet.DataTable1);
                CrystalReport1 crystalReport1 = new CrystalReport1();
                crystalReport1.SetDataSource(dataSet);
                crystalReportViewer1.ReportSource = crystalReport1;
            }

            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);
            }

        }

        private void reportDocument1_InitReport(object sender, EventArgs e)
        {

        }

        private void Report_Load(object sender, EventArgs e)
        {
            if(connection.State==ConnectionState.Open)
            {
                connection.Close();
            }
            connection.Open();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ManagerForm managerForm = new ManagerForm();
            managerForm.Show();
            this.Hide();
        }

        private void crystalReportViewer1_Load(object sender, EventArgs e)
        {

        }
    }
}
