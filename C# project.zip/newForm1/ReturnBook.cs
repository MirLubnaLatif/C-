﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace newForm1
{
   
    public partial class ReturnBook : Form
    {
        SqlConnection connection = new SqlConnection("Data Source = Localhost; Initial Catalog = Library1; Integrated Security = True");
        public ReturnBook()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView1.Visible = true;
            grid(StudentClsID.Text);
        }

        private void ReturnBook_Load(object sender, EventArgs e)
        {
            if (connection.State == ConnectionState.Open)
            {
                connection.Close();
            }
            connection.Open();
        }
        public void grid(string StudentClsID)
        {
            //connection.Open();
            SqlCommand command = connection.CreateCommand();
            command.CommandType = CommandType.Text;
            command.CommandText = "select * from IssueBokk where StudentID ='"+StudentClsID.ToString()+"' and BookReturnDate=''";
            command.ExecuteNonQuery();
            DataTable dataTable = new DataTable();
            SqlDataAdapter dataAdapter = new SqlDataAdapter(command);

            dataAdapter.Fill(dataTable);
            dataGridView1.DataSource = dataTable;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            panel3.Visible = true;
            int i;
            i = Convert.ToInt32(dataGridView1.SelectedCells[0].Value.ToString());
            SqlCommand command = connection.CreateCommand();
            command.CommandType = CommandType.Text;
            command.CommandText = "select * from IssueBokk where IssueID='"+i+"'";
            command.ExecuteNonQuery();
            DataTable dataTable = new DataTable();
            SqlDataAdapter dataAdapter = new SqlDataAdapter(command);

            dataAdapter.Fill(dataTable);
            dataGridView1.DataSource = dataTable;

            foreach (DataRow dataRow in dataTable.Rows)
            {
                BookName.Text = dataRow["BookName"].ToString();
                textBox3.Text = Convert.ToString(dataRow["BookIssueDate"].ToString());
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int i;
            i = Convert.ToInt32(dataGridView1.SelectedCells[0].Value.ToString());
            SqlCommand command = connection.CreateCommand();
            command.CommandType = CommandType.Text;
            command.CommandText = "update IssueBokk set BookReturnDate='"+dateTimePicker1.Value.ToString()+"' where IssueID='"+i+"'";
            command.ExecuteNonQuery();

            SqlCommand command1 = connection.CreateCommand();
            command1.CommandType = CommandType.Text;
            command1.CommandText = "update BookDetail set AvailableBook =AvailableBook+1 where BookName='"+BookName.Text+ "'";
            command1.ExecuteNonQuery();

            MessageBox.Show("Book Returned Successfully");

            
            panel3.Visible = true;
            grid(StudentClsID.Text);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ManagerForm managerForm = new ManagerForm();
            managerForm.Show();
            this.Hide();
        }
    }
}
